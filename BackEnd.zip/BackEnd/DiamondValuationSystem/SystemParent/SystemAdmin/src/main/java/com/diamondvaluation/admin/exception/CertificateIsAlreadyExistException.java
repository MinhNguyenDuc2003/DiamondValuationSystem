package com.diamondvaluation.admin.exception;

public class CertificateIsAlreadyExistException extends RuntimeException{
	public CertificateIsAlreadyExistException(String message) {
		super(message);
	}
}
