package com.diamondvaluation.admin.exception;

public class RefreshTokenExpiredException extends Exception{

}
