package com.diamondvaluation.admin.exception;

public class CertificateNotFoundException extends RuntimeException{
	public CertificateNotFoundException(String message) {
		super(message);
	}
}
