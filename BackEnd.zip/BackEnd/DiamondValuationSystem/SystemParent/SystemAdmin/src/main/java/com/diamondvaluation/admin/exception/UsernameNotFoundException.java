package com.diamondvaluation.admin.exception;

public class UsernameNotFoundException extends RuntimeException{
	public UsernameNotFoundException(String message) {
		super(message);
	}
}
