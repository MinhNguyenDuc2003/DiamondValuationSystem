package com.diamondvaluation.admin.exception;

public class ServiceNameIsAlreadyExistException extends RuntimeException{
	public ServiceNameIsAlreadyExistException(String message) {
		super(message);
	}
}
