package com.diamondvaluation.admin.exception;

public class CaratIsNotFoundException extends RuntimeException{
	public CaratIsNotFoundException(String message) {
		super(message);
	}
}
