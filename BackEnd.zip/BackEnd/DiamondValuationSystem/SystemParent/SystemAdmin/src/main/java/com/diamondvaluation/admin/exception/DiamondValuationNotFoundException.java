package com.diamondvaluation.admin.exception;

public class DiamondValuationNotFoundException extends RuntimeException{
	public DiamondValuationNotFoundException(String message) {
		super(message);
	}
}
