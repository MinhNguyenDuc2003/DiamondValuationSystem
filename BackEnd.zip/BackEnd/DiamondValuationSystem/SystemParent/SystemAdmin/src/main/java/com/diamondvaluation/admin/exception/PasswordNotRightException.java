package com.diamondvaluation.admin.exception;

public class PasswordNotRightException extends RuntimeException{
	public PasswordNotRightException(String message) {
		super(message);
	}
}
