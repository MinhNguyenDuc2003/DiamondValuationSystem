package com.diamondvaluation.admin.exception;

public class RefreshTokenNotFoundException extends Exception{

}
