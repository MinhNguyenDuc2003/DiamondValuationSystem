package com.diamondvaluation.shop.exception;

public class RefreshTokenNotFoundException extends Exception{

}
