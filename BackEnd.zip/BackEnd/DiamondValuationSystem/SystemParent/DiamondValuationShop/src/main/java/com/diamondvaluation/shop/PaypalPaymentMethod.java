package com.diamondvaluation.shop;

public enum PaypalPaymentMethod {

	credit_card, paypal
	
}
