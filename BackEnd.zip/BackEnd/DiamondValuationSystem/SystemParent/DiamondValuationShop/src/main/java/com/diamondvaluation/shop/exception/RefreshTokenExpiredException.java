package com.diamondvaluation.shop.exception;

public class RefreshTokenExpiredException extends Exception{

}
