package com.diamondvaluation.shop;

public class CheckoutInfo {
	private float paymentTotal;
}
