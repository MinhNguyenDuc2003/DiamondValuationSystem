package com.diamondvaluation.shop;

public enum PaypalPaymentIntent {

	sale, authorize, order
	
}