package com.diamondvaluation.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiamondValuationShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
