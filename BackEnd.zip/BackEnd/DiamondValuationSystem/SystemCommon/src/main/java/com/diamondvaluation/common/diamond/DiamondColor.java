package com.diamondvaluation.common.diamond;

public enum DiamondColor {
	D, E, F, G, H, I, J, K, L, M, N, O, P;
}
