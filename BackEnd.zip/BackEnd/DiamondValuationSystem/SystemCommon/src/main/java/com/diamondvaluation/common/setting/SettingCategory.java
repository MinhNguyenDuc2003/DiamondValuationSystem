package com.diamondvaluation.common.setting;

public enum SettingCategory {
	GENERAL, MAIL_SERVER, MAIL_TEMPLATES, PAYMENT
}
