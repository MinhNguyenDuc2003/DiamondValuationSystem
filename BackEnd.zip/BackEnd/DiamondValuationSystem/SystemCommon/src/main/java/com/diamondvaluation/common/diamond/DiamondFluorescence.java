package com.diamondvaluation.common.diamond;

public enum DiamondFluorescence {
	None, Faint, Medium, Strong
}
