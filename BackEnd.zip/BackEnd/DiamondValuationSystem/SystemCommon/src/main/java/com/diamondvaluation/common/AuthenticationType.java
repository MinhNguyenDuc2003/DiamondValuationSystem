package com.diamondvaluation.common;

public enum AuthenticationType {
	DATABASE, GOOGLE, FACEBOOK
}
