package com.diamondvaluation.common;

public enum RequestStatus {
	WAIT, NEW, PROCESSING, PROCESSED, DONE, BLOCKREQUEST, BLOCKED
}
