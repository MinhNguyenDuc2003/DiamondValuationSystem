package com.diamondvaluation.common.diamond;

public enum DiamondMake {
	Ideal, Excellent, VeryGood, Good, Fair, Poor;
}
