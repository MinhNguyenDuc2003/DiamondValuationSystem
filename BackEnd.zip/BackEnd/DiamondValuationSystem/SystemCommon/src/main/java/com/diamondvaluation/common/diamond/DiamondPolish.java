package com.diamondvaluation.common.diamond;

public enum DiamondPolish {
	Excellent, VeryGood, Good, Fair, Poor
}
