package com.diamondvaluation.common.diamond;

public enum DiamondCut {
	Round, Marquise, Pear, Oval, Heart, Emerald, Princess, Radiant, Triangle, Baguette, Asscher, Cushion;
}
