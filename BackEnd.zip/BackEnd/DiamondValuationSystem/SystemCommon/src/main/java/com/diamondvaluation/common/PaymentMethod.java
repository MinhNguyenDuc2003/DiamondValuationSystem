package com.diamondvaluation.common;

public enum PaymentMethod {
	TM,CK ;
}
