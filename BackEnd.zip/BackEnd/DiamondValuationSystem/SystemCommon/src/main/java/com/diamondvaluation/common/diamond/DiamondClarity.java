package com.diamondvaluation.common.diamond;

public enum DiamondClarity {
	IF,VVS, VVS1, VVS2,VS, VS1, VS2, SI1, SI2, SI3, I1, I2, I3;
}
