package com.diamondvaluation.common.diamond;

public enum DiamondSymmetry {
	Excellent, VeryGood, Good, Fair, Poor
}
