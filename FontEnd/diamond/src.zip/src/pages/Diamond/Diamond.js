import React from 'react'
import './Diamond.scss'

const Diamond = () => {
  return (
    <div className='wrapperrr'>Diamod</div>
  )
}

export default Diamond