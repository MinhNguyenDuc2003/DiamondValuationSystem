import React from 'react'
import './Contact.scss'

const Contact = () => {
  return (
    
    <div className='wrapperrr' >
      Contact</div>
  )
}

export default Contact